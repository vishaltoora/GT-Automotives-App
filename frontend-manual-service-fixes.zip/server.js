const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 8080;

// Backend configuration - Using API fixes deployment
const BACKEND_URL = 'http://gt-automotives-backend-api-fixes.canadacentral.azurecontainer.io:3000';

// CORS middleware for API routes
app.use('/api', (req, res, next) => {
  res.header('Access-Control-Allow-Origin', 'https://gt-automotives.com');
  res.header('Access-Control-Allow-Credentials', 'true');
  res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  
  if (req.method === 'OPTIONS') {
    res.sendStatus(200);
  } else {
    next();
  }
});

// API Proxy - Forward all /api requests to backend
app.use('/api', createProxyMiddleware({
  target: BACKEND_URL,
  changeOrigin: true,
  secure: true,
  timeout: 30000,
  logLevel: 'info',
  onError: (err, req, res) => {
    console.error('Proxy error:', err.message);
    res.status(500).json({ 
      error: 'Backend service unavailable',
      message: err.message 
    });
  },
  onProxyReq: (proxyReq, req, res) => {
    console.log(`Proxying: ${req.method} ${req.url} -> ${BACKEND_URL}${req.url}`);
  }
}));

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ 
    status: 'healthy', 
    service: 'gt-automotive-web-app',
    backend: BACKEND_URL,
    build: 'manual-20250916-123823-service-fixes',
    commit: '$(git rev-parse HEAD)',
    timestamp: new Date().toISOString()
  });
});

// Serve static files (React app)
app.use(express.static(__dirname));

// Handle client-side routing (SPA) - Must be last
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.listen(PORT, () => {
  console.log(`🚀 GT Automotive Web App running on port ${PORT}`);
  console.log(`📡 Proxying API requests to: ${BACKEND_URL}`);
  console.log(`🌐 Frontend: https://gt-automotives.com`);
  console.log(`🔗 API: https://gt-automotives.com/api`);
  console.log(`🏗️ Build: manual-20250916-123823-service-fixes`);
});
